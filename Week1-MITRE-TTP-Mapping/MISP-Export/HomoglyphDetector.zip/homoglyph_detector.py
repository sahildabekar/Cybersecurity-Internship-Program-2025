import argparse
import unicodedata
import difflib
from urllib.parse import urlparse

# Mapping of common homoglyphs
HOMOGLYPHS = {
    'а': 'a', 'е': 'e', 'і': 'i', 'о': 'o', 'р': 'p', 'с': 'c', 'у': 'y', 'х': 'x',
    'Α': 'A', 'Β': 'B', 'Ε': 'E', 'Ζ': 'Z', 'Η': 'H', 'Ι': 'I', 'Κ': 'K',
    'Μ': 'M', 'Ν': 'N', 'Ο': 'O', 'Ρ': 'P', 'Τ': 'T', 'Υ': 'Y', 'Χ': 'X',
    'а': 'a', 'с': 'c', 'е': 'e', 'і': 'i', 'ј': 'j', 'о': 'o', 'р': 'p',
    'ѕ': 's', 'у': 'y', 'ѡ': 'w'
}

def normalize_url(url):
    return ''.join(HOMOGLYPHS.get(char, char) for char in url)

def detect_homoglyphs(url):
    normalized = normalize_url(url)
    similarity = difflib.SequenceMatcher(None, url, normalized).ratio()
    return normalized, similarity

def shorten_url(url):
    parsed = urlparse(url)
    return parsed.netloc

def main():
    parser = argparse.ArgumentParser(description="Homoglyph Detector Tool")
    parser.add_argument("url", help="Input URL to check for homoglyphs")
    args = parser.parse_args()

    print(f"Original URL: {args.url}")
    normalized_url, similarity = detect_homoglyphs(args.url)
    print(f"Normalized URL: {normalized_url}")
    print(f"Similarity Score: {similarity:.2f}")

    short_url = shorten_url(args.url)
    print(f"Shortened URL: {short_url}")

if __name__ == "__main__":
    main()
