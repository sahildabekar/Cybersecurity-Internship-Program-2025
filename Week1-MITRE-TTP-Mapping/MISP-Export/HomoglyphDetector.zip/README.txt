# Homoglyph Detector Tool

This tool detects homoglyphs in a given URL and prints the normalized version along with a shortened domain.

## How to Run

### Requirements
- Python 3.x

### Steps
1. Extract the ZIP folder.
2. Open terminal/command prompt.
3. Navigate to the extracted folder.
4. Run the script using the following command:

```
python homoglyph_detector.py <url>
```

Replace `<url>` with the URL you want to test. Example:

```
python homoglyph_detector.py http://xn--googl-9za.com
```

### Output
- Original URL
- Normalized (homoglyph-removed) URL
- Similarity score between original and normalized URL
- Shortened URL (domain part only)
